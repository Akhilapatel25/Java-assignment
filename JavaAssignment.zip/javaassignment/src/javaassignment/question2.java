package javaassignment;

public class question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		   int number = 2345;
	        number += 8;
	        number /= 3;
	        number %= 5;
	        number *= 5;
	        System.out.println("Final result using assignment operators: " + number);

	}

}
