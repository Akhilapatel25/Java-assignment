package javaassignment;

public class question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   int totalstudents=90;
	        int boys=45;
	        int gradeA=totalstudents/2;
	        int boysGradeA=20;
	        int girlsGradeA=gradeA-boysGradeA;
	        System.out.println("Total number of girls who got grade A: " + girlsGradeA);

	}

}
/*
Total number of girls who got grade A: 25

*/